package com.devst.appestudiante;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * VISTA 2 - INICIO / DASHBOARD
 * Pantalla principal despues de iniciar sesion.
 */
public class InicioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
    }

    // ---------- Tarjetas de accesos rapidos ----------
    // (son informativas, solo muestran un Toast al tocarlas)

    public void onClickTarjeta(View view) {
        Toast.makeText(this, "Sección en construcción", Toast.LENGTH_SHORT).show();
    }

    // ---------- Menu inferior ----------
    // Estos 3 metodos los exige el layout menu_inferior.xml

    public void irInicio(View view) {
        // Ya estamos en Inicio, no hacemos nada
        Toast.makeText(this, "Ya estás en Inicio", Toast.LENGTH_SHORT).show();
    }

    public void irPerfil(View view) {
        Intent i = new Intent(this, PerfilActivity.class);
        startActivity(i);
        finish();
    }

    public void irAcerca(View view) {
        Intent i = new Intent(this, AcercaActivity.class);
        startActivity(i);
        finish();
    }
}
