package com.devst.appestudiante;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * VISTA 4 - ACERCA DE
 * Informacion de la aplicacion y del desarrollador.
 */
public class AcercaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca);
    }

    // ---------- Menu inferior ----------

    public void irInicio(View view) {
        Intent i = new Intent(this, InicioActivity.class);
        startActivity(i);
        finish();
    }

    public void irPerfil(View view) {
        Intent i = new Intent(this, PerfilActivity.class);
        startActivity(i);
        finish();
    }

    public void irAcerca(View view) {
        Toast.makeText(this, "Ya estás en Acerca de", Toast.LENGTH_SHORT).show();
    }
}
