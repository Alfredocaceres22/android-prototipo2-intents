package com.devst.appestudiante;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * VISTA 3 - PERFIL
 * Muestra los datos del estudiante y permite cerrar sesion.
 */
public class PerfilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
    }

    /**
     * Cierra la sesion y regresa al Login.
     */
    public void onClickCerrarSesion(View view) {

        Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show();

        Intent volverAlLogin = new Intent(this, LoginActivity.class);

        // Estas dos "flags" borran todo el historial de pantallas anteriores,
        // asi el usuario no puede volver atras con el boton fisico.
        volverAlLogin.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(volverAlLogin);
        finish();
    }

    // ---------- Menu inferior ----------

    public void irInicio(View view) {
        Intent i = new Intent(this, InicioActivity.class);
        startActivity(i);
        finish();
    }

    public void irPerfil(View view) {
        Toast.makeText(this, "Ya estás en Perfil", Toast.LENGTH_SHORT).show();
    }

    public void irAcerca(View view) {
        Intent i = new Intent(this, AcercaActivity.class);
        startActivity(i);
        finish();
    }
}
