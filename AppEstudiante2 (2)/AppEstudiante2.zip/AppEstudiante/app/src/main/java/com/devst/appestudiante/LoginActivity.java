package com.devst.appestudiante;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * VISTA 1 - LOGIN
 * Valida el usuario contra credenciales fijas definidas en el codigo.
 */
public class LoginActivity extends AppCompatActivity {

    // Variables que representan los campos del formulario
    private EditText etUsuario, etPassword;

    // Credenciales fijas (sin base de datos, como pide la actividad)
    private static final String USUARIO_VALIDO = "admin";
    private static final String PASS_VALIDO = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Vincula esta Activity con res/layout/activity_login.xml
        setContentView(R.layout.activity_login);

        // Conectamos las variables Java con los ID del XML
        etUsuario = findViewById(R.id.eTUsusario);
        etPassword = findViewById(R.id.eTPassword);
    }

    /**
     * Este metodo se ejecuta al presionar el boton INGRESAR.
     * El nombre debe coincidir con android:onClick="onClickIngresar" del XML.
     */
    public void onClickIngresar(View view) {

        // 1. Leemos lo que escribio el usuario
        String usuario = etUsuario.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // 2. Validamos que no esten vacios
        if (usuario.isEmpty()) {
            Toast.makeText(this, "Ingrese su usuario", Toast.LENGTH_SHORT).show();
            etUsuario.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Ingrese su contraseña", Toast.LENGTH_SHORT).show();
            etPassword.requestFocus();
            return;
        }

        // 3. Comparamos con las credenciales fijas
        if (usuario.equals(USUARIO_VALIDO) && password.equals(PASS_VALIDO)) {

            Toast.makeText(this, "Bienvenido a MyCampus", Toast.LENGTH_SHORT).show();

            // Navegamos a la vista 2 (Dashboard)
            Intent irAInicio = new Intent(this, InicioActivity.class);
            startActivity(irAInicio);

            // Cerramos el login para que el boton Atras no vuelva aqui
            finish();

        } else {
            // Credenciales incorrectas
            Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }
    }
}
